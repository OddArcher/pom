import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class bkgrnd extends PApplet {

int speed = 30;
int start = 1;
int size = 1000;
int rect = 0;
int ellipse = 0;
int triangle = 0;
int line = 0;
int point = 0;
int background1 = 0;
int background2 = 0;
int monochrome = 0;
int colors = 1;

public void setup(){
  background(0,0,0);
  frameRate(speed);
  
}

public void draw(){
text("Made By Ricky", 450, 980);
if(start == 1){
  if(monochrome == 1){
    if(background1 == 1){
      background(0,0,0);
    }
    stroke(random(255));
    fill(random(255));
    if(rect == 1){
      rect(random(size),random(size),random(size),random(size));
    }
    if(ellipse == 1){
      ellipse(random(size),random(size),random(size),random(size));
    }
    if(triangle == 1){
      triangle(random(size),random(size),random(size),random(size),random(size),random(size));
    }
    if(line == 1){
      line(random(size),random(size),random(size),random(size));
    }
    if(point == 1){
      point(random(size),random(size));
    }
    if(background2 == 1){
      background(0,0,0);
    }
  }
  
    if(colors == 1){
    if(background1 == 1){
      background(0,0,0);
    }
    stroke(random(255),random(255),random(255));
    fill(random(255),random(255),random(255));
    if(rect == 1){
      rect(random(size),random(size),random(size),random(size));
    }
    if(ellipse == 1){
      ellipse(random(size),random(size),random(size),random(size));
    }
    if(triangle == 1){
      triangle(random(size),random(size),random(size),random(size),random(size),random(size));
    }
    if(line == 1){
      line(random(size),random(size),random(size),random(size));
    }
    if(point == 1){
      point(random(size),random(size));
    }
    if(background2 == 1){
      background(0,0,0);
    }
  }
}  
}

public void keyPressed() {
  if(key == 'q' || key == 'Q'){
    if(rect == 1){
      rect = 0;
    }
    else {
      rect = 1;
    }
  }
  if(key == 'w' || key == 'W'){
    if(ellipse == 1){
      ellipse = 0;
    }
    else {
      ellipse = 1;
    }
  }
  if(key == 'e' || key == 'E'){
    if(triangle == 1){
      triangle = 0;
    }
    else {
      triangle = 1;
    }
  }
  if(key == 'r' || key == 'R'){
    if(line == 1){
      line = 0;
    }
    else {
      line = 1;
    }
  }
  if(key == 't' || key == 'T'){
    if(point == 1){
      point = 0;
    }
    else {
      point = 1;
    }
  }
  if(key == 'a' || key == 'A'){
  if(background1 == 1){
      background1 = 0;
    }
    else {
      background1 = 1;
    }
  }
  if(key == 's' || key == 'S'){
    if(background2 == 1){
      background2 = 0;
    }
    else {
      background2 = 1;
    }
  }
  if(key == 'd' || key == 'D'){
    if(start == 1){
      start = 0;
    }
    else {
      start = 1;
    }
  }
  if(key == 'z' || key == 'Z'){
  colors = 1;
  monochrome = 0;
  }
  if(key == 'x' || key == 'X'){
  colors = 0;
  monochrome = 1;
  }
}
  public void settings() {  size(1000,1000); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "bkgrnd" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
