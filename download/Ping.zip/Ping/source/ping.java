import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class ping extends PApplet {

// More Vars
int start = 0;
int p1score1 = 0;
int p1score2 = 0;
int p2score1 = 0;
int p2score2 = 0;
float multiplyer;
int bounce = 0;

// Player 1
int p1x = 300;
int p1y = 650;
int p1x2 = p1x + 100;
int p1w = 100;
int p1l = 20;
int p1ri = 0;
int p1le = 0;
int p1s = 5;

// Player 2
int p2x = 300;
int p2y = 25;
int p2x2 = p2x + 100;
int p2w = 100;
int p2l = 20;
int p2ri = 0;
int p2le = 0;
int p2s = 5;

// Ball
int bx = 350;
int by = 350;
int bsi = 20;
int bhspeed = 0;
int bvspeed = 0;

// Wall
int w1x = 0;
int w1w = 5;
int w2x = 695;
int w2w = 5;

// Setup
public void setup() {
  
}

// Draw
public void draw() {
  if(p1score1 >= 10){
    p1score1 = 0;
    p1score2++;
  }
  if(p2score1 >= 10){
    p2score1 = 0;
    p2score2++;
  }
  background(0);
//Redo Variables
p1x2 = p1x + p1w;
p2x2 = p2x + p2w;
// Ball Collisions
if(bx >= w2x){
  bhspeed = -bhspeed;
}
if(bx <= w1x){
  bhspeed = -bhspeed;
}
if(by == p1y && bx >= p1x && bx <= p1x2){
  if(bounce == 0){
      if (random(1) >= 0.5f){
        bhspeed = floor(random(-6,-3));
      }
      else {
        bhspeed = floor(random(-6,-3));
      }
      if (random(1) >= 0.5f){
        bvspeed = floor(random(-6,-3));
      }
      else {
        bvspeed = floor(random(-6,-3));
      }
      bounce = 1;
  }
  else{
    bvspeed = -bvspeed;
  }
  bvspeed -= .1f;
  bhspeed -= .1f;
}
if(by == p2y + p2y && bx >= p2x && bx <= p2x2){
    if(bounce == 0){
      if (random(1) >= 0.5f){
        bhspeed = floor(random(6,3));
      }
      else {
        bhspeed = floor(random(6,3));
      }
      if (random(1) >= 0.5f){
        bvspeed = floor(random(6,3));
      }
      else {
        bvspeed = floor(random(6,3));
      }
      bounce = 1;
    }
  else{
    bvspeed = -bvspeed;
  }
  bvspeed += .1f;
  bhspeed += .1f;
}
if(by > 700){
  bhspeed = 0;
  bvspeed = 0;
  bx = 350;
  by = 350;
  p2score1++;
  start = 0;
  bounce = 0;
}
if(by < 0){
  bhspeed = 0;
  bvspeed = 0;
  bx = 350;
  by = 350;
  p1score1++;
  start = 0;
  bounce = 0;
}
// Number 10
if(p1score2 != 1 && p1score2 != 4){
     //Top
rect(60,375,40,5);
}
if(p1score2 != 0 && p1score2 != 1 && p1score2 != 7){
    //Middle
rect(60,413,40,5);  
}
if(p1score2 != 1 && p1score2 != 4 && p1score2 != 7){
    //Bottom
rect(60,450,40,5);  
}
if(p1score2 != 1 && p1score2 != 2 && p1score2 != 3 && p1score2 != 7){
    //Top Left
rect(60,380,5,35);  
}
if(p1score2 != 5 && p1score2 != 6){
    //Top Right
rect(95,380,5,35);    
}
if(p1score2 != 1 && p1score2 != 3 && p1score2 != 4 && p1score2 != 5 && p1score2 != 7 && p1score2 != 9){
    //Bottom Left
rect(60,415,5,35);     
}
if(p1score2 != 2){
    //Bottom Right
rect(95,415,5,35);    
}
// Number 1
if(p1score1 != 1 && p1score1 != 4){
     //Top
rect(60 + 50,375,40,5);
}
if(p1score1 != 0 && p1score1 != 1 && p1score1 != 7){
    //Middle
rect(60 + 50,413,40,5);  
}
if(p1score1 != 1 && p1score1 != 4 && p1score1 != 7){
    //Bottom
rect(60 + 50,450,40,5);  
}
if(p1score1 != 1 && p1score1 != 2 && p1score1 != 3 && p1score1 != 7){
    //Top Left
rect(60 + 50,380,5,35);  
}
if(p1score1 != 5 && p1score1 != 6){
    //Top Right
rect(95 + 50,380,5,35);    
}
if(p1score1 != 1 && p1score1 != 3 && p1score1 != 4 && p1score1 != 5 && p1score1 != 7 && p1score1 != 9){
    //Bottom Left
rect(60 + 50,415,5,35);     
}
if(p1score1 != 2){
    //Bottom Right
rect(95 + 50,415,5,35);    
}
// Number 2 10
if(p2score2 != 1 && p2score2 != 4){
    //Top
rect(600 - 50,250,40,5);
}
if(p2score2 != 0 && p2score2 != 1 && p2score2 != 7){
    //Middle
rect(600 - 50,288,40,5); 
}
if(p2score2 != 1 && p2score2 != 4 && p2score2 != 7){
    //Bottom
rect(600 - 50,325,40,5);  
}
if(p2score2 != 1 && p2score2 != 2 && p2score2 != 3 && p2score2 != 7){
    //Top Left
rect(600 - 50,255,5,35);
}
if(p2score2 != 5 && p2score2 != 6){
    //Top Right
rect(635 - 50,255,5,35);
}
if(p2score2 != 1 && p2score2 != 3 && p2score2 != 4 && p2score2 != 5 && p2score2 != 7 && p2score2 != 9){
    //Bottom Left
rect(600 - 50,290,5,35);     
}
if(p2score2 != 2){
    //Bottom Right
rect(635 - 50,290,5,35);   
}
// Number 2
if(p2score1 != 1 && p2score1 != 4){
    //Top
rect(600,250,40,5);
}
if(p2score1 != 0 && p2score1 != 1 && p2score1 != 7){
    //Middle
rect(600,288,40,5); 
}
if(p2score1 != 1 && p2score1 != 4 && p2score1 != 7){
    //Bottom
rect(600,325,40,5);  
}
if(p2score1 != 1 && p2score1 != 2 && p2score1 != 3 && p2score1 != 7){
    //Top Left
rect(600,255,5,35);
}
if(p2score1 != 5 && p2score1 != 6){
    //Top Right
rect(635,255,5,35);
}
if(p2score1 != 1 && p2score1 != 3 && p2score1 != 4 && p2score1 != 5 && p2score1 != 7 && p2score1 != 9){
    //Bottom Left
rect(600,290,5,35);     
}
if(p2score1 != 2){
    //Bottom Right
rect(635,290,5,35);   
}

//Wall
  rect(w1x,0,w2w,700);
  rect(w2x,0,w2w,700);
//Line
  rect(30,345,40,10);
  rect(90,345,40,10);
  rect(150,345,40,10);
  rect(210,345,40,10);
  rect(270,345,40,10);
  rect(330,345,40,10);
  rect(390,345,40,10);
  rect(450,345,40,10);
  rect(510,345,40,10);
  rect(570,345,40,10);
  rect(630,345,40,10);
//Player 1
  rect(p1x,p1y,p1w,p1l);
//Player 2
  rect(p2x,p2y,p2w,p2l);
//Ball
  ellipse(bx,by,bsi,bsi);
//Move Stuffs
  if(p1x != 600){
    p1x += p1ri;
  }
  if(p1x != 0){
    p1x -= p1le;
  }
  
  if(p2x != 600){  
    p2x += p2ri;
  }
  if(p2x != 0){    
    p2x -= p2le;
  }
  if(start == 1){
    bx += bhspeed;
    by += bvspeed;
  }
}

public void keyPressed() {
  //Player 1 Move
  if(key == 'd' || key == 'D'){
    p1ri = p1s;
  }
  if(key == 'a' || key == 'A'){
    p1le = p1s;
  }
  
  //Player 2 Move
  if(key == 'l' || key == 'L'){
    p2ri = p2s;
  }
  if(key == 'j' || key == 'J'){
    p2le = p2s;
  }
  // Start
  if(key == 'g' || key == 'G'){
    if(start == 0){
      start = 1;
      bounce = 0;
      if (random(1) >= 0.5f){
        bvspeed = 5;
      }
      else {
        bvspeed = -5;
      }
    }
  }
}
public void keyReleased() {
  //Player 1 Move
  if(key == 'd' || key == 'D'){
    p1ri = 0;
  }
  if(key == 'a' || key == 'A'){
    p1le = 0;
  }
  
  //Player 2 Move
  if(key == 'l' || key == 'L'){
    p2ri = 0;
  }
  if(key == 'j' || key == 'J'){
    p2le = 0;
  }
}
  public void settings() {  size(700,700); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "ping" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
